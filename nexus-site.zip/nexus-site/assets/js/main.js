// ─── LOADER ───────────────────────────────────────────
window.addEventListener('load', () => {
  setTimeout(() => {
    const l = document.getElementById('loader');
    if (l) l.classList.add('hidden');
  }, 1900);
});

// ─── ACTIVE NAV ITEM (by current URL) ─────────────────
(function() {
  const path = window.location.pathname;
  document.querySelectorAll('.nav-item[href]').forEach(a => {
    const href = a.getAttribute('href');
    if (path.endsWith(href) || path.endsWith(href.replace('.html',''))) {
      a.classList.add('active');
    }
  });
})();

// ─── PROGRESS (localStorage) ──────────────────────────
const PAGES = [
  'index.html','foundations.html','tracing.html','osint.html','tools.html',
  'typologies/economic-crimes.html','typologies/electronic-crimes.html',
  'typologies/blockchain-pcmltf.html','advanced/dfir.html',
  'advanced/malware.html','reference/case-studies.html',
  'reference/legal-process.html','reference/asset-forfeiture.html',
  'reference/glossary.html'
];
function updateProgress() {
  const visited = JSON.parse(localStorage.getItem('nexus-visited') || '[]');
  const path = window.location.pathname.split('/').slice(-2).join('/');
  const page = PAGES.find(p => path.endsWith(p) || path.endsWith(p.split('/').pop())) || '';
  if (page && !visited.includes(page)) { visited.push(page); localStorage.setItem('nexus-visited', JSON.stringify(visited)); }
  const pct = Math.min(100, Math.round((visited.length / PAGES.length) * 100));
  const fill = document.getElementById('progressFill');
  const label = document.getElementById('progressPct');
  if (fill) fill.style.width = pct + '%';
  if (label) label.textContent = pct + '%';
}
updateProgress();

// ─── MOBILE NAV ───────────────────────────────────────
function toggleMobileNav() {
  document.getElementById('sidebar').classList.toggle('open');
}

// ─── DRILLDOWN ACCORDIONS ─────────────────────────────
function toggleDrilldown(header) {
  const body = header.nextElementSibling;
  const isOpen = body.classList.contains('open');

  document.querySelectorAll('.drilldown-body.open').forEach(b => {
    b.classList.remove('open');
    b.previousElementSibling.classList.remove('open');
  });

  if (!isOpen) {
    body.classList.add('open');
    header.classList.add('open');
    const firstTab = body.querySelector('.sub-tab');
    if (firstTab) {
      body.querySelectorAll('.sub-tab').forEach(t => t.classList.remove('active'));
      body.querySelectorAll('.subcategory-panel').forEach(p => p.classList.remove('active'));
      firstTab.classList.add('active');
      const m = firstTab.getAttribute('onclick').match(/'([^']+)'\)$/);
      if (m) { const panel = document.getElementById(m[1]); if (panel) panel.classList.add('active'); }
    }
    setTimeout(() => header.scrollIntoView({ behavior: 'smooth', block: 'nearest' }), 150);
  }
}

// ─── SUB-TABS ─────────────────────────────────────────
function switchTab(tabEl, panelId) {
  const tabGroup = tabEl.closest('.subcategory-tabs');
  const panelGroup = tabEl.closest('.drilldown-body').querySelector('.subcategory-panels');
  tabGroup.querySelectorAll('.sub-tab').forEach(t => t.classList.remove('active'));
  panelGroup.querySelectorAll('.subcategory-panel').forEach(p => p.classList.remove('active'));
  tabEl.classList.add('active');
  const panel = document.getElementById(panelId);
  if (panel) panel.classList.add('active');
}

// ─── GLOSSARY FILTER ──────────────────────────────────
function filterGlossary() {
  const q = (document.getElementById('glossarySearch').value || '').toLowerCase();
  document.querySelectorAll('.glossary-item').forEach(item => {
    item.style.display = item.textContent.toLowerCase().includes(q) ? '' : 'none';
  });
}

// ─── SCROLL TO TOP ────────────────────────────────────
window.addEventListener('scroll', () => {
  const btn = document.getElementById('scrollTop');
  if (btn) btn.classList.toggle('visible', window.scrollY > 400);
});
